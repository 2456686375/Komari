# Komari Glass Theme

Vite + React + TypeScript + Tailwind CSS + shadcn-style UI 主题骨架。

## 使用

```bash
pnpm install
pnpm dev
```

构建：

```bash
pnpm build
```

构建后会生成 `dist/`，然后将 `komari-theme.json` + `dist/` 压缩为 zip 上传到 Komari 即可。

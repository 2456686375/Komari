import React, { useEffect, useMemo, useState } from "react";
import {
  Cpu,
  HardDrive,
  Network,
  Activity,
  Server,
  Globe2
} from "lucide-react";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ModeToggle } from "@/components/mode-toggle";

interface PublicSettings {
  sitename: string;
  description: string;
  theme: string;
  theme_settings?: ThemeSettings | null;
}

interface PublicResponse {
  status: string;
  message: string;
  data: PublicSettings;
}

type AccentColor = "紫色" | "蓝色" | "粉色" | "青色";

interface ThemeSettings {
  accent_color?: AccentColor;
  show_price?: boolean;
  show_ping_chart?: boolean;
}

interface KomariNode {
  uuid: string;
  name: string;
  cpu_name: string;
  virtualization: string;
  arch: string;
  cpu_cores: number;
  os: string;
  kernel_version: string;
  gpu_name: string;
  region: string;
  mem_total: number;
  swap_total: number;
  disk_total: number;
  group: string;
  tags: string;
  price: number;
  currency: string;
  billing_cycle: number;
  auto_renewal: boolean;
  traffic_limit: number;
  traffic_limit_type: string;
  expired_at: string | null;
  hidden: boolean;
}

interface NodesResponse {
  status: string;
  message: string;
  data: KomariNode[];
}

interface NodeRecentData {
  cpu: { usage: number };
  ram: { total: number; used: number };
  swap: { total: number; used: number };
  disk: { total: number; used: number };
  network: {
    up: number;
    down: number;
    totalUp: number;
    totalDown: number;
  };
  connections: { tcp: number; udp: number };
  uptime: number;
  process: number;
  updated_at: string;
}

interface RecentResponse {
  status: string;
  message: string;
  data: NodeRecentData[];
}

type ViewMode = "grid" | "table";

function formatBytes(bytes?: number, fractionDigits = 1) {
  if (!bytes || bytes <= 0) return "0 B";
  const units = ["B", "KB", "MB", "GB", "TB"];
  const index = Math.min(
    Math.floor(Math.log(bytes) / Math.log(1024)),
    units.length - 1
  );
  const value = bytes / Math.pow(1024, index);
  return `${value.toFixed(fractionDigits)} ${units[index]}`;
}

function formatUptime(seconds?: number) {
  if (!seconds || seconds <= 0) return "刚刚启动";
  const d = Math.floor(seconds / 86400);
  const h = Math.floor((seconds % 86400) / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  if (d > 0) return `${d}天${h}小时`;
  if (h > 0) return `${h}小时${m}分钟`;
  return `${m}分钟`;
}

function accentGradient(accent: AccentColor): string {
  switch (accent) {
    case "蓝色":
      return "from-sky-400/80 to-cyan-400/80";
    case "粉色":
      return "from-pink-400/80 to-rose-400/80";
    case "青色":
      return "from-emerald-400/80 to-teal-400/80";
    case "紫色":
    default:
      return "from-violet-400/80 to-fuchsia-400/80";
  }
}

export default function App() {
  const [publicInfo, setPublicInfo] = useState<PublicSettings | null>(null);
  const [nodes, setNodes] = useState<KomariNode[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const [viewMode, setViewMode] = useState<ViewMode>(() => {
    if (typeof window === "undefined") return "grid";
    const stored = window.localStorage.getItem("nodeViewMode");
    return stored === "table" ? "table" : "grid";
  });

  const [selectedGroup, setSelectedGroup] = useState<string>(() => {
    if (typeof window === "undefined") return "all";
    return window.localStorage.getItem("nodeSelectedGroup") || "all";
  });

  useEffect(() => {
    const controller = new AbortController();

    async function load() {
      try {
        setLoading(true);
        setError(null);

        const [pubRes, nodesRes] = await Promise.all([
          fetch("/api/public", { signal: controller.signal }),
          fetch("/api/nodes", { signal: controller.signal })
        ]);

        const pubJson: PublicResponse = await pubRes.json();
        const nodesJson: NodesResponse = await nodesRes.json();

        setPublicInfo(pubJson.data);
        setNodes(nodesJson.data ?? []);
      } catch (err: any) {
        if (err?.name === "AbortError") return;
        console.error(err);
        setError("加载 Komari 数据失败，请检查后端 /api 是否可访问。");
      } finally {
        setLoading(false);
      }
    }

    load();

    return () => controller.abort();
  }, []);

  const groups = useMemo(() => {
    const set = new Set<string>();
    nodes.forEach((n) => {
      if (n.group && !n.hidden) set.add(n.group);
    });
    return Array.from(set);
  }, [nodes]);

  const visibleNodes = useMemo(
    () =>
      nodes.filter((n) => {
        if (n.hidden) return false;
        if (selectedGroup === "all") return true;
        return n.group === selectedGroup;
      }),
    [nodes, selectedGroup]
  );

  const accent: AccentColor =
    publicInfo?.theme_settings?.accent_color ?? "紫色";
  const showPrice = publicInfo?.theme_settings?.show_price ?? false;

  const handleGroupChange = (group: string) => {
    setSelectedGroup(group);
    if (typeof window !== "undefined") {
      window.localStorage.setItem("nodeSelectedGroup", group);
    }
  };

  const handleViewModeChange = (mode: ViewMode) => {
    setViewMode(mode);
    if (typeof window !== "undefined") {
      window.localStorage.setItem("nodeViewMode", mode);
    }
  };

  return (
    <div className="relative min-h-screen overflow-hidden bg-gradient-to-br from-slate-950 via-slate-900 to-indigo-950 text-slate-100">
      <div className="pointer-events-none absolute inset-0 opacity-70">
        <div className="absolute -top-32 -left-24 h-72 w-72 rounded-full bg-pink-500/18 blur-3xl" />
        <div className="absolute -bottom-24 -right-16 h-80 w-80 rounded-full bg-indigo-500/22 blur-3xl" />
      </div>

      <main className="relative z-10 flex min-h-screen items-center justify-center p-4 md:p-8">
        <section className="glass-panel w-full max-w-6xl backdrop-blur-[50px]">
          <div className="flex flex-col gap-6 p-4 md:p-8">
            <header className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
              <div>
                <div className="inline-flex items-center gap-2 rounded-full bg-slate-900/70 px-3 py-1 text-xs font-medium text-slate-300 ring-1 ring-indigo-400/60">
                  <span className="h-2 w-2 rounded-full bg-emerald-400 shadow-[0_0_12px_rgba(52,211,153,0.9)]" />
                  <span>Komari Glass Theme</span>
                </div>
                <h1 className="mt-4 text-2xl font-semibold tracking-tight sm:text-3xl">
                  {publicInfo?.sitename ?? "Komari Monitor"}
                </h1>
                <p className="mt-2 text-sm text-slate-300">
                  {publicInfo?.description ??
                    "简洁的服务器监控面板 · 玻璃拟态 + 紫蓝渐变风格。"}
                </p>
              </div>
              <div className="flex items-center gap-3 self-end md:self-auto">
                <div className="hidden flex-col text-right text-xs text-slate-400 sm:flex">
                  <span>当前主题：KomariGlass</span>
                  <span>{nodes.length} 台服务器 · Vite + React + Tailwind</span>
                </div>
                <ModeToggle />
              </div>
            </header>

            <section className="mt-2 flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
              <div className="flex flex-wrap items-center gap-2">
                <Button
                  size="sm"
                  variant={selectedGroup === "all" ? "default" : "outline"}
                  className={`rounded-full border border-slate-600/70 bg-slate-900/80 px-3 text-xs ${
                    selectedGroup === "all"
                      ? "bg-gradient-to-r " + accentGradient(accent)
                      : ""
                  }`}
                  onClick={() => handleGroupChange("all")}
                >
                  全部分组
                </Button>
                {groups.map((group) => (
                  <Button
                    key={group}
                    size="sm"
                    variant={selectedGroup === group ? "default" : "outline"}
                    className={`rounded-full border border-slate-700/70 bg-slate-900/80 px-3 text-xs ${
                      selectedGroup === group
                        ? "bg-gradient-to-r " + accentGradient(accent)
                        : ""
                    }`}
                    onClick={() => handleGroupChange(group)}
                  >
                    {group || "未分组"}
                  </Button>
                ))}
              </div>

              <div className="flex items-center gap-2">
                <Button
                  size="sm"
                  variant={viewMode === "grid" ? "default" : "outline"}
                  className="rounded-full border border-slate-600/70 bg-slate-900/80 px-3 text-xs"
                  onClick={() => handleViewModeChange("grid")}
                >
                  卡片视图
                </Button>
                <Button
                  size="sm"
                  variant={viewMode === "table" ? "default" : "outline"}
                  className="rounded-full border border-slate-600/70 bg-slate-900/80 px-3 text-xs"
                  onClick={() => handleViewModeChange("table")}
                >
                  表格视图
                </Button>
              </div>
            </section>

            <section className="mt-4 space-y-4">
              {loading ? (
                <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
                  {Array.from({ length: 6 }).map((_, idx) => (
                    <div
                      key={idx}
                      className="h-40 animate-pulse rounded-2xl bg-slate-900/60"
                    />
                  ))}
                </div>
              ) : error ? (
                <Card className="border border-rose-500/40 bg-rose-950/50 text-rose-50">
                  <CardHeader>
                    <CardTitle className="text-sm">加载失败</CardTitle>
                    <CardDescription className="text-xs text-rose-100/80">
                      {error}
                    </CardDescription>
                  </CardHeader>
                </Card>
              ) : visibleNodes.length === 0 ? (
                <Card className="border border-slate-700/60 bg-slate-950/60 text-slate-200">
                  <CardHeader>
                    <CardTitle className="text-sm">暂无可见节点</CardTitle>
                    <CardDescription className="text-xs text-slate-400">
                      请在 Komari 后台添加节点，或取消隐藏设置。
                    </CardDescription>
                  </CardHeader>
                </Card>
              ) : viewMode === "grid" ? (
                <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
                  {visibleNodes.map((node) => (
                    <NodeCard
                      key={node.uuid}
                      node={node}
                      accent={accent}
                      showPrice={showPrice}
                    />
                  ))}
                </div>
              ) : (
                <NodeTable nodes={visibleNodes} />
              )}
            </section>

            <footer className="mt-6 flex flex-col gap-2 border-t border-slate-800/70 pt-4 text-xs text-slate-400 sm:flex-row sm:items-center sm:justify-between">
              <span>Powered by Komari Monitor.</span>
              <span>KomariGlass · 玻璃拟态主题 · Tailwind + shadcn/ui</span>
            </footer>
          </div>
        </section>
      </main>
    </div>
  );
}

interface NodeCardProps {
  node: KomariNode;
  accent: AccentColor;
  showPrice: boolean;
}

function NodeCard({ node, accent, showPrice }: NodeCardProps) {
  const [recent, setRecent] = useState<NodeRecentData | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;

    async function loadRecent() {
      try {
        const res = await fetch(`/api/recent/${node.uuid}`);
        if (!res.ok) return;
        const json: RecentResponse = await res.json();
        const first = json.data?.[0];
        if (!cancelled && first) setRecent(first);
      } catch (err) {
        console.error(err);
      } finally {
        if (!cancelled) setLoading(false);
      }
    }

    loadRecent();
    return () => {
      cancelled = true;
    };
  }, [node.uuid]);

  const cpuPercent = recent?.cpu.usage ?? 0;
  const memPercent =
    recent && recent.ram.total > 0
      ? (recent.ram.used / recent.ram.total) * 100
      : 0;
  const diskPercent =
    recent && recent.disk.total > 0
      ? (recent.disk.used / recent.disk.total) * 100
      : 0;

  const chipGradient = accentGradient(accent);

  return (
    <Card className="relative overflow-hidden border border-slate-700/80 bg-slate-950/70 shadow-[0_16px_40px_rgba(15,23,42,0.9)] transition-all hover:border-slate-100/50 hover:bg-slate-900/85">
      <div
        className={`pointer-events-none absolute inset-x-0 top-0 h-[2px] bg-gradient-to-r ${chipGradient}`}
      />
      <CardHeader className="flex flex-row items-start justify-between gap-2 pb-2">
        <div className="space-y-1">
          <CardTitle className="flex items-center gap-2 text-sm font-semibold text-slate-50">
            <span className="inline-flex h-6 w-6 items-center justify-center rounded-xl bg-slate-900/70 ring-1 ring-slate-600/70">
              <Server className="h-3.5 w-3.5 text-slate-200" />
            </span>
            <span className="truncate">{node.name}</span>
          </CardTitle>
          <CardDescription className="flex flex-wrap items-center gap-1 text-[11px] text-slate-300">
            {node.group && (
              <span className="rounded-full bg-slate-900/80 px-2 py-0.5 text-[10px] text-slate-200 ring-1 ring-slate-600/80">
                {node.group}
              </span>
            )}
            {node.region && (
              <span className="inline-flex items-center gap-1 rounded-full bg-slate-900/80 px-2 py-0.5 text-[10px] text-slate-300 ring-1 ring-slate-600/80">
                <Globe2 className="h-3 w-3" />
                <span>{node.region}</span>
              </span>
            )}
            <span className="truncate text-slate-400">
              {node.cpu_name} · {node.cpu_cores}C · {node.arch}
            </span>
          </CardDescription>
        </div>
        <div className="flex flex-col items-end gap-1 text-right">
          {showPrice && node.price > -1 && (
            <span className="rounded-full bg-slate-900/90 px-2 py-0.5 text-[10px] text-emerald-200 ring-1 ring-emerald-400/60">
              {node.currency}
              {node.price} / {node.billing_cycle}天
            </span>
          )}
          <span className="text-[10px] text-slate-400">
            {formatUptime(recent?.uptime)}
          </span>
        </div>
      </CardHeader>

      <CardContent className="space-y-3 pt-1">
        <StatRow
          icon={<Cpu className="h-4 w-4 text-violet-300" />}
          label="CPU"
          value={
            loading
              ? "加载中…"
              : `${cpuPercent.toFixed(1).replace(/\.0$/, "")}%`
          }
          percent={Math.max(0, Math.min(cpuPercent, 100))}
        />
        <StatRow
          icon={<Activity className="h-4 w-4 text-sky-300" />}
          label="内存"
          value={
            loading
              ? "加载中…"
              : `${memPercent.toFixed(1).replace(/\.0$/, "")}% · ${formatBytes(
                  recent?.ram.used
                )}/${formatBytes(recent?.ram.total)}`
          }
          percent={Math.max(0, Math.min(memPercent, 100))}
        />
        <StatRow
          icon={<HardDrive className="h-4 w-4 text-emerald-300" />}
          label="磁盘"
          value={
            loading
              ? "加载中…"
              : `${diskPercent.toFixed(1).replace(/\.0$/, "")}% · ${formatBytes(
                  recent?.disk.used
                )}/${formatBytes(recent?.disk.total)}`
          }
          percent={Math.max(0, Math.min(diskPercent, 100))}
        />
        <StatRow
          icon={<Network className="h-4 w-4 text-cyan-300" />}
          label="网络"
          value={
            loading
              ? "加载中…"
              : `${formatBytes(recent?.network.down)}/s ↓ · ${formatBytes(
                  recent?.network.up
                )}/s ↑`
          }
        />
      </CardContent>
    </Card>
  );
}

interface StatRowProps {
  icon?: React.ReactNode;
  label: string;
  value: string;
  percent?: number;
}

function StatRow({ icon, label, value, percent }: StatRowProps) {
  return (
    <div className="space-y-1.5">
      <div className="flex items-center justify-between text-[11px]">
        <div className="flex items-center gap-1.5 text-slate-300">
          {icon && <span>{icon}</span>}
          <span>{label}</span>
        </div>
        <span className="font-medium text-slate-50">{value}</span>
      </div>
      {typeof percent === "number" && (
        <div className="h-1.5 overflow-hidden rounded-full bg-slate-800/90">
          <div
            className="h-full rounded-full bg-gradient-to-r from-emerald-400 via-sky-400 to-fuchsia-400"
            style={{ width: `${percent}%` }}
          />
        </div>
      )}
    </div>
  );
}

interface NodeTableProps {
  nodes: KomariNode[];
}

function NodeTable({ nodes }: NodeTableProps) {
  return (
    <div className="overflow-x-auto rounded-2xl border border-slate-800/90 bg-slate-950/70">
      <table className="min-w-full divide-y divide-slate-800/80 text-xs">
        <thead className="bg-slate-950/90 text-slate-300">
          <tr>
            <th className="px-4 py-2 text-left font-medium">名称</th>
            <th className="px-4 py-2 text-left font-medium">分组</th>
            <th className="px-4 py-2 text-left font-medium">位置</th>
            <th className="px-4 py-2 text-left font-medium">配置</th>
            <th className="px-4 py-2 text-left font-medium">系统</th>
            <th className="px-4 py-2 text-left font-medium">磁盘</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-slate-800/60">
          {nodes.map((node) => (
            <tr key={node.uuid} className="hover:bg-slate-900/80">
              <td className="px-4 py-2 text-slate-50">{node.name}</td>
              <td className="px-4 py-2 text-slate-200">
                {node.group || "未分组"}
              </td>
              <td className="px-4 py-2 text-slate-300">
                {node.region || "-"}
              </td>
              <td className="px-4 py-2 text-slate-300">
                {node.cpu_cores}C · {node.arch}
              </td>
              <td className="px-4 py-2 text-slate-300">
                {node.os.split(" (")[0]}
              </td>
              <td className="px-4 py-2 text-slate-300">
                {formatBytes(node.disk_total)}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

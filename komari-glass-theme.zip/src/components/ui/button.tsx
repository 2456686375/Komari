import * as React from "react";
import { Slot } from "@radix-ui/react-slot";
import { cva, type VariantProps } from "class-variance-authority";
import { cn } from "@/lib/utils";

const buttonVariants = cva(
  "inline-flex items-center justify-center whitespace-nowrap rounded-xl text-sm font-medium transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-slate-400 disabled:pointer-events-none disabled:opacity-60 border border-slate-700/70 bg-slate-900/80 text-slate-50 hover:bg-slate-800/90 hover:border-slate-200/80 ring-offset-slate-950",
  {
    variants: {
      variant: {
        default:
          "bg-gradient-to-r from-violet-500/90 via-fuchsia-500/90 to-sky-400/90 text-slate-50 hover:from-violet-400 hover:via-fuchsia-400 hover:to-sky-300 border-none shadow-[0_0_24px_rgba(129,140,248,0.65)]",
        outline:
          "bg-transparent text-slate-100 border-slate-600/80 hover:bg-slate-900/80",
        ghost:
          "bg-transparent hover:bg-slate-900/60 text-slate-100 border-none"
      },
      size: {
        default: "h-9 px-4 py-2",
        sm: "h-8 rounded-full px-3 text-xs",
        lg: "h-10 rounded-xl px-6 text-base",
        icon: "h-9 w-9 rounded-xl"
      }
    },
    defaultVariants: {
      variant: "default",
      size: "default"
    }
  }
);

export interface ButtonProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement>,
    VariantProps<typeof buttonVariants> {
  asChild?: boolean;
}

const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className, variant, size, asChild = false, ...props }, ref) => {
    const Comp = asChild ? Slot : "button";
    return (
      <Comp
        className={cn(buttonVariants({ variant, size }), className)}
        ref={ref}
        {...props}
      />
    );
  }
);

Button.displayName = "Button";

export { Button, buttonVariants };
